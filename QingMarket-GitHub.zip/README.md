# QingMarket

Dashboard cryptocurrency sederhana untuk GitHub Pages.

## Menjalankan di GitHub Pages

1. Buat repository baru di GitHub, misalnya `qingmarket`.
2. Upload `index.html`, `style.css`, `app.js`, dan `README.md`.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`.
6. Simpan dan tunggu beberapa menit.
7. GitHub akan memberikan alamat website Pages kamu.

## Data

Versi awal menggunakan CoinGecko public API. Tidak ada API key di dalam repository.

## Catatan

API publik memiliki batas penggunaan. Untuk platform besar/komersial, gunakan backend/proxy dan perhatikan ketentuan layanan API yang dipakai.
