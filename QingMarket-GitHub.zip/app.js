const API = "https://api.coingecko.com/api/v3";
let coins = [];
const table = document.getElementById("coinTable");
const search = document.getElementById("search");
const statusEl = document.getElementById("status");

const money = n => {
  if (n == null || Number.isNaN(Number(n))) return "—";
  const x = Number(n);
  if (Math.abs(x) >= 1e12) return "$" + (x/1e12).toFixed(2) + "T";
  if (Math.abs(x) >= 1e9) return "$" + (x/1e9).toFixed(2) + "B";
  if (Math.abs(x) >= 1e6) return "$" + (x/1e6).toFixed(2) + "M";
  if (Math.abs(x) >= 1e3) return "$" + (x/1e3).toFixed(2) + "K";
  if (x >= 1) return "$" + x.toLocaleString("en-US",{maximumFractionDigits:2});
  return "$" + x.toLocaleString("en-US",{maximumSignificantDigits:5});
};
const pct = n => n == null ? "—" : `${Number(n).toFixed(2)}%`;
const cls = n => Number(n) >= 0 ? "up" : "down";

function render(list){
  table.innerHTML = list.map((c,i)=>`
    <tr>
      <td>${c.market_cap_rank ?? i+1}</td>
      <td>
        <div class="coin-cell">
          <img class="coin-icon" src="${c.image}" alt="" loading="lazy">
          <div><span class="coin-name">${escapeHtml(c.name)}</span><span class="symbol">${escapeHtml(c.symbol)}</span></div>
        </div>
      </td>
      <td>${money(c.current_price)}</td>
      <td class="${cls(c.price_change_percentage_1h_in_currency)}">${pct(c.price_change_percentage_1h_in_currency)}</td>
      <td class="${cls(c.price_change_percentage_24h)}">${pct(c.price_change_percentage_24h)}</td>
      <td class="${cls(c.price_change_percentage_7d_in_currency)}">${pct(c.price_change_percentage_7d_in_currency)}</td>
      <td>${money(c.market_cap)}</td>
      <td>${money(c.total_volume)}</td>
    </tr>`).join("");
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}

async function loadMarket(){
  statusEl.textContent = "Loading market data…";
  try{
    const [markets, global] = await Promise.all([
      fetch(`${API}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=1h,7d`).then(r=>r.ok?r.json():Promise.reject(r)),
      fetch(`${API}/global`).then(r=>r.ok?r.json():Promise.reject(r))
    ]);
    coins = markets;
    render(coins);
    const d = global.data;
    document.getElementById("marketCap").textContent = money(d.total_market_cap.usd);
    document.getElementById("volume").textContent = money(d.total_volume.usd);
    document.getElementById("btcDom").textContent = pct(d.market_cap_percentage.btc);
    document.getElementById("activeCoins").textContent = Number(d.active_cryptocurrencies).toLocaleString();
    document.getElementById("marketCapChange").textContent = pct(d.market_cap_change_percentage_24h_usd) + " / 24h";
    statusEl.textContent = `Updated ${new Date().toLocaleTimeString()}`;
  }catch(e){
    statusEl.textContent = "Data gagal dimuat. Coba Refresh beberapa saat lagi.";
    table.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:35px;color:#888">Unable to load market data.</td></tr>`;
  }
}

search.addEventListener("input",()=>{
  const q=search.value.toLowerCase().trim();
  render(coins.filter(c=>c.name.toLowerCase().includes(q)||c.symbol.toLowerCase().includes(q)));
});
document.getElementById("refreshBtn").addEventListener("click",loadMarket);
document.getElementById("themeBtn").addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("qingmarket-theme",document.body.classList.contains("dark")?"dark":"light");
});
if(localStorage.getItem("qingmarket-theme")==="dark") document.body.classList.add("dark");
loadMarket();
