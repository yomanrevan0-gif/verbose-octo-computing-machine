const API="https://api.coinpaprika.com/v1/tickers?quotes=USD";
let coins=[], filter="all", watchlist=JSON.parse(localStorage.getItem("qm_watch")||"[]");
const $=id=>document.getElementById(id);
const fmtMoney=n=>{if(!n)return"$0";if(n>=1e12)return"$"+(n/1e12).toFixed(2)+"T";if(n>=1e9)return"$"+(n/1e9).toFixed(2)+"B";if(n>=1e6)return"$"+(n/1e6).toFixed(2)+"M";return"$"+Number(n).toLocaleString("en-US",{maximumFractionDigits:n<1?6:2})};
const pct=n=>n==null?"—":(n>=0?"+":"")+Number(n).toFixed(2)+"%";
const logo=id=>`https://static.coinpaprika.com/coin/${id}/logo.png`;
const coinMap=()=>Object.fromEntries(coins.map(c=>[c.id,c]));

async function loadMarket(){
 $("marketTable").innerHTML='<tr><td colspan="9" class="loading">Loading live market data…</td></tr>';
 try{
  const r=await fetch(API); if(!r.ok)throw Error();
  coins=(await r.json()).filter(c=>c.quotes?.USD).sort((a,b)=>(b.quotes.USD.market_cap||0)-(a.quotes.USD.market_cap||0)).slice(0,100);
  updateStats(); renderWatchlist(); renderTable(); renderSearchResults(); renderPortfolio();
 }catch(e){$("marketTable").innerHTML='<tr><td colspan="9" class="loading">Market data could not be loaded. Tap Refresh.</td></tr>'}
}
function updateStats(){
 let cap=coins.reduce((s,c)=>s+(c.quotes.USD.market_cap||0),0), vol=coins.reduce((s,c)=>s+(c.quotes.USD.volume_24h||0),0), btc=coins.find(c=>c.symbol==="BTC");
 $("marketCap").textContent=fmtMoney(cap); $("volume").textContent=fmtMoney(vol); $("activeCoins").textContent=coins.length;
 $("btcDom").textContent=btc?((btc.quotes.USD.market_cap/cap)*100).toFixed(2)+"%":"—";
}
function visibleCoins(){
 let q=($("tableSearch")?.value||"").toLowerCase().trim(), a=[...coins];
 if(q)a=a.filter(c=>c.name.toLowerCase().includes(q)||c.symbol.toLowerCase().includes(q));
 if(filter==="gainers")a.sort((x,y)=>(y.quotes.USD.percent_change_24h||0)-(x.quotes.USD.percent_change_24h||0));
 if(filter==="losers")a.sort((x,y)=>(x.quotes.USD.percent_change_24h||0)-(y.quotes.USD.percent_change_24h||0));
 return a;
}
function renderTable(){
 const a=visibleCoins(); $("marketTable").innerHTML=a.map((c,i)=>{let u=c.quotes.USD, h=u.percent_change_24h||0, on=watchlist.includes(c.id);
 return `<tr><td>${i+1}</td><td><div class="asset"><img src="${logo(c.id)}" onerror="this.style.visibility='hidden'"><div><b>${c.name}</b><small>${c.symbol}</small></div></div></td><td><b>${fmtMoney(u.price)}</b></td><td class="${(u.percent_change_1h||0)>=0?'green':'red'}">${pct(u.percent_change_1h)}</td><td class="${h>=0?'green':'red'}">${pct(h)}</td><td class="${(u.percent_change_7d||0)>=0?'green':'red'}">${pct(u.percent_change_7d)}</td><td>${fmtMoney(u.market_cap)}</td><td>${fmtMoney(u.volume_24h)}</td><td><button class="star ${on?'on':''}" onclick="toggleWatch('${c.id}')">★</button></td></tr>`}).join("")||'<tr><td colspan="9" class="loading">No coin found.</td></tr>';
}
function toggleWatch(id){watchlist=watchlist.includes(id)?watchlist.filter(x=>x!==id):[...watchlist,id];localStorage.setItem("qm_watch",JSON.stringify(watchlist));renderWatchlist();renderTable()}
function clearWatchlist(){watchlist=[];localStorage.removeItem("qm_watch");renderWatchlist();renderTable()}
function renderWatchlist(){
 const a=watchlist.map(id=>coinMap()[id]).filter(Boolean); $("watchGrid").innerHTML=a.length?a.map(c=>{let u=c.quotes.USD,h=u.percent_change_24h||0;return `<div class="coin-card"><button class="watch-btn on" onclick="toggleWatch('${c.id}')">★</button><div class="coin-head"><img class="coin-logo" src="${logo(c.id)}"><div><div class="coin-name">${c.name}</div><div class="symbol">${c.symbol}</div></div></div><div class="coin-price">${fmtMoney(u.price)}</div><div class="${h>=0?'green':'red'}">${pct(h)}</div></div>`}).join(""):'<div class="coin-card" style="grid-column:1/-1;color:var(--muted)">Your watchlist is empty. Tap ★ on a coin to add it.</div>';
}
function renderSearchResults(){
 const input=$("modalSearch"); if(!input)return; const q=input.value.toLowerCase().trim(); if(!q){$("searchResults").innerHTML="";return}
 const a=coins.filter(c=>c.name.toLowerCase().includes(q)||c.symbol.toLowerCase().includes(q)).slice(0,10);
 $("searchResults").innerHTML=a.map(c=>`<div class="result" onclick="jumpToCoin('${c.id}')"><img src="${logo(c.id)}"><div><b>${c.name}</b><small>${c.symbol} · ${fmtMoney(c.quotes.USD.price)}</small></div></div>`).join("");
}
function openSearch(){ $("searchModal").classList.add("show");$("modalSearch").focus()}
function closeSearch(){ $("searchModal").classList.remove("show")}
function jumpToCoin(id){closeSearch();$("tableSearch").value=coinMap()[id]?.name||"";renderTable();$("markets").scrollIntoView({behavior:"smooth"})}
function addDemoHolding(){let p=JSON.parse(localStorage.getItem("qm_portfolio")||"[]");p.push({symbol:"BTC",qty:.001});localStorage.setItem("qm_portfolio",JSON.stringify(p));renderPortfolio()}
function renderPortfolio(){let p=JSON.parse(localStorage.getItem("qm_portfolio")||"[]"),btc=coins.find(c=>c.symbol==="BTC"),v=btc?p.filter(x=>x.symbol==="BTC").reduce((s,x)=>s+x.qty*btc.quotes.USD.price,0):0;$("portfolioValue").textContent=fmtMoney(v);$("portfolioAssets").textContent=p.length}
function openDrawer(){$("drawer").classList.add("show")}function closeDrawer(){$("drawer").classList.remove("show")}
$("tableSearch").addEventListener("input",renderTable);$("modalSearch").addEventListener("input",renderSearchResults);
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");filter=b.dataset.filter;renderTable()}));
$("searchBtn").onclick=openSearch;$("menuBtn").onclick=openDrawer;document.querySelectorAll(".drawer a").forEach(a=>a.onclick=closeDrawer);
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeSearch();closeDrawer()}});
loadMarket();setInterval(loadMarket,60000);
