# QingMarket V3

Educational cryptocurrency market dashboard for GitHub Pages.

Features:
- Live market ticker
- Top cryptocurrency table
- Search/filter
- Watchlist saved in localStorage
- Exchange overview UI
- Demo portfolio saved locally
- Responsive mobile UI

Important: this is an independent educational project and is not affiliated with CoinMarketCap, Binance, Coinbase, Kraken, or CoinPaprika.

GitHub Pages is static hosting. Do not put private API keys, passwords, payment credentials, or server-side secrets in this repository.
